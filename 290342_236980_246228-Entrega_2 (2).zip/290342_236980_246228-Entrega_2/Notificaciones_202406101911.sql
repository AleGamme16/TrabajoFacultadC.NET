INSERT INTO BddDiseno1.dbo.Notificaciones (Mensaje,UsuarioID,ReservaID,Fecha) VALUES
	 (N'Su reserva del depósito DepoC ha sido aprobada.',17,15,'2024-06-10 10:55:25.8571190'),
	 (N'Su reserva del depósito DepoParaMayores ha sido aprobada.',16,78,'2024-06-10 17:26:53.0849300'),
	 (N'Su reserva del depósito DepoParaMayores ha sido aprobada.',16,77,'2024-06-10 17:26:53.8570762'),
	 (N'Su reserva del depósito DepoParaMayores ha sido aprobada.',16,76,'2024-06-10 17:26:54.3972986'),
	 (N'Su reserva del depósito DepoVioleta ha sido aprobada.',19,74,'2024-06-10 17:26:55.0308451'),
	 (N'Su reserva del depósito DepoGarage ha sido aprobada.',18,31,'2024-06-10 17:26:56.0840329'),
	 (N'Su reserva del depósito DepoGarage ha sido aprobada.',18,30,'2024-06-10 17:26:56.6359136'),
	 (N'Su reserva del depósito DepoParaMessi ha sido aprobada.',18,80,'2024-06-10 17:29:14.8025805'),
	 (N'Su reserva del depósito DepoGarage ha sido rechazada. Motivo: Tiempo de espera caducado..',18,29,'2024-06-10 17:30:37.6593739');
