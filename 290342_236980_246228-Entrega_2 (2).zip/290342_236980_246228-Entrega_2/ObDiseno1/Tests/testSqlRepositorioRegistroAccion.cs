﻿using Backend;
using Backend.Context;
using Backend.SQL;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Linq;

namespace Tests
{
    [TestClass]
    public class SqlRepositorioRegistroAccionesTests
    {
        private SqlRepositorioRegistroAcciones _repositoryRegistroAcciones;
        private AppDataContext _context;
        private readonly IAppContextFactory _contextFactory = new MemoryAppContext();

        [TestInitialize]
        public void SetUp()
        {
            _context = _contextFactory.CreateDbContext();
            _repositoryRegistroAcciones = new SqlRepositorioRegistroAcciones(_context);
        }

        [TestCleanup]
        public void CleanUp()
        {
            _context.Database.EnsureDeleted();
        }

        [TestMethod]
        public void Test_AgregarRegistroAccion()
        {
            var usuario = new Usuario { ID = 1, Nombre = "Juan", Apellido = "Perez", Contrasena = "Password123", Mail = "juan.perez@example.com", Rol = EnumRol.Cliente };
            //var registroAccion = new RegistroAccion { TipoAccion = "Creo una valoracion", Usuario = usuario, FechaHora = DateTime.Now };

            //_repositoryRegistroAcciones.AgregarRegistroAccion(registroAccion.TipoAccion, registroAccion.Usuario, registroAccion.FechaHora);

            var registroInDb = _context.Registros.First();
            //Assert.AreEqual(registroAccion.TipoAccion, registroInDb.TipoAccion);
            //Assert.AreEqual(registroAccion.Usuario, registroInDb.Usuario);
            //Assert.AreEqual(registroAccion.FechaHora, registroInDb.FechaHora);
        }

        [TestMethod]
        public void Test_ObtenerTodosLosRegistros()
        {
            var usuario = new Usuario { ID = 1, Nombre = "Juan", Apellido = "Perez", Contrasena = "Password123", Mail = "juan.perez@example.com", Rol = EnumRol.Cliente };
            //var registroAccion = new RegistroAccion { TipoAccion = "Creo una valoracion", Usuario = usuario, FechaHora = DateTime.Now };

            //_context.Registros.Add(registroAccion);
            _context.SaveChanges();

            var registrosInDb = _repositoryRegistroAcciones.ObtenerTodosLosRegistros();

            //Assert.IsTrue(registrosInDb.Contains(registroAccion));
            Assert.AreEqual(1, registrosInDb.Count());
        }
    }
}

