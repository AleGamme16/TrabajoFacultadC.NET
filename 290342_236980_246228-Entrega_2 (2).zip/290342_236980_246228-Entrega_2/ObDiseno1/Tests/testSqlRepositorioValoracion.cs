﻿using Backend;
using Backend.Context;
using Backend.SQL;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Linq;

namespace Tests
{
    [TestClass]
    public class SqlRepositorioValoracionTests
    {
        private SqlRepositorioValoracion _repositoryValoracion;
        private AppDataContext _context;
        private SqlRepositorioRegistroAcciones _repositoryRegistro;
        private readonly IAppContextFactory _contextFactory = new MemoryAppContext();

        [TestInitialize]
        public void SetUp()
        {
            _context = _contextFactory.CreateDbContext();
            _repositoryRegistro = new SqlRepositorioRegistroAcciones(_context);
            _repositoryValoracion = new SqlRepositorioValoracion(_context, _repositoryRegistro);
        }

        [TestCleanup]
        public void CleanUp()
        {
            _context.Database.EnsureDeleted();
        }

        [TestMethod]
        public void Test_AgregarValoracion()
        {
            var valoracion = new Valoracion
            {
                ID = 1,
                Estrellas = 5,
                Comentario = "Excelente servicio",
                Usuario = new Usuario { ID = 1, Nombre = "Juan", Apellido = "Perez", Contrasena = "Password123", Mail = "juan.perez@example.com", Rol = EnumRol.Cliente },
                Deposito = new Deposito { ID = 1, Area = EnumArea.A, Tamano = EnumTamano.Pequeno, Climatizado = true }
            };

            _repositoryValoracion.AgregarValoracion(valoracion);

            var valoracionInDb = _context.Valoraciones.First();
            Assert.AreEqual(valoracion, valoracionInDb);
        }

        [TestMethod]
        public void Test_ExisteValoracion()
        {
            var valoracion = new Valoracion
            {
                ID = 1,
                Estrellas = 5,
                Comentario = "Excelente servicio",
                Usuario = new Usuario { ID = 1, Nombre = "Juan", Apellido = "Perez", Contrasena = "Password123", Mail = "juan.perez@example.com", Rol = EnumRol.Cliente },
                Deposito = new Deposito { ID = 1, Area = EnumArea.A, Tamano = EnumTamano.Pequeno, Climatizado = true }
            };

            _context.Valoraciones.Add(valoracion);
            _context.SaveChanges();

            var existe = _repositoryValoracion.ExisteValoracion(valoracion);
            Assert.IsTrue(existe);
        }

        [TestMethod]
        public void Test_BorrarValoracion()
        {
            var valoracion = new Valoracion
            {
                ID = 1,
                Estrellas = 5,
                Comentario = "Excelente servicio",
                Usuario = new Usuario { ID = 1, Nombre = "Juan", Apellido = "Perez", Contrasena = "Password123", Mail = "juan.perez@example.com", Rol = EnumRol.Cliente },
                Deposito = new Deposito { ID = 1, Area = EnumArea.A, Tamano = EnumTamano.Pequeno, Climatizado = true }
            };

            _context.Valoraciones.Add(valoracion);
            _context.SaveChanges();

            _repositoryValoracion.BorrarValoracion(valoracion);

            var valoracionesInDb = _repositoryValoracion.ObtenerValoraciones();
            Assert.IsFalse(valoracionesInDb.Contains(valoracion));
            Assert.AreEqual(0, valoracionesInDb.Count());
        }

        [TestMethod]
        public void Test_ObtenerValoraciones()
        {
            var valoracion = new Valoracion
            {
                ID = 1,
                Estrellas = 5,
                Comentario = "Excelente servicio",
                Usuario = new Usuario { ID = 1, Nombre = "Juan", Apellido = "Perez", Contrasena = "Password123", Mail = "juan.perez@example.com", Rol = EnumRol.Cliente },
                Deposito = new Deposito { ID = 1, Area = EnumArea.A, Tamano = EnumTamano.Pequeno, Climatizado = true }
            };

            _context.Valoraciones.Add(valoracion);
            _context.SaveChanges();

            var valoracionesInDb = _repositoryValoracion.ObtenerValoraciones();

            Assert.IsTrue(valoracionesInDb.Contains(valoracion));
            Assert.AreEqual(1, valoracionesInDb.Count());
        }

        [TestMethod]
        public void Test_RetornarValoracionPorId()
        {
            var valoracion = new Valoracion
            {
                ID = 1,
                Estrellas = 5,
                Comentario = "Excelente servicio",
                Usuario = new Usuario { ID = 1, Nombre = "Juan", Apellido = "Perez", Contrasena = "Password123", Mail = "juan.perez@example.com", Rol = EnumRol.Cliente },
                Deposito = new Deposito { ID = 1, Area = EnumArea.A, Tamano = EnumTamano.Pequeno, Climatizado = true }
            };

            _context.Valoraciones.Add(valoracion);
            _context.SaveChanges();

            var valoracionInDb = _repositoryValoracion.RetornarValoracionPorId(valoracion.ID);
            Assert.AreEqual(valoracion, valoracionInDb);
        }
    }
}


