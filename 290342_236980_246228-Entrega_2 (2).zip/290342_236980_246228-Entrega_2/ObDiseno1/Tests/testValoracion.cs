﻿using Backend;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tests
{
    [TestClass]
    public class testValoracion
    {
        [TestMethod]
        public void TestCrearValoracionSinParametros()
        {
            Deposito depo = new Deposito();
            Usuario user = new Usuario();

            Valoracion valor = new Valoracion();

            Assert.AreEqual(1, valor.Estrellas);
            Assert.AreEqual("-", valor.Comentario);
            Assert.AreEqual(depo, valor.Deposito);
            Assert.AreEqual(user, valor.Usuario);
            Assert.AreEqual(9999, valor.ID);
        }

        [TestMethod]
        public void TestCrearValoracionConParametros()
        {
            DateTime desde = new DateTime(2024, 10, 03);
            DateTime hasta = new DateTime(2024, 11, 16);

            Promocion promo = new Promocion("", 0.10m, desde, hasta);
            Deposito depo = new Deposito(EnumArea.B, EnumTamano.Mediano, true, promo);
            Usuario user = new Usuario("Jorge", "Perez", "Contr$en4", "asdf@gmail.com");

            Valoracion valor = new Valoracion(1, "-", depo, user);

            Assert.AreEqual(1, valor.Estrellas);
            Assert.AreEqual("-", valor.Comentario);
            Assert.AreEqual(depo, valor.Deposito);
            Assert.AreEqual(user, valor.Usuario);
        }

        [TestMethod]
        public void TestEstrellasValidasCasoLimite1()
        {
            DateTime desde = new DateTime(2024, 10, 8);
            DateTime hasta = new DateTime(2024, 11, 16);

            Promocion promo = new Promocion("", 0.10m, desde, hasta);
            Deposito depo = new Deposito(EnumArea.B, EnumTamano.Mediano, true, promo);
            Usuario user = new Usuario("Jorge", "Perez", "Contr$en4", "asdf@gmail.com");

            Valoracion valor = new Valoracion(1, "-", depo, user);

            Assert.AreEqual(1, valor.Estrellas);
            Assert.AreEqual("-", valor.Comentario);
            Assert.AreEqual(depo, valor.Deposito);
            Assert.AreEqual(user, valor.Usuario);
        }

        [TestMethod]
        public void TestEstrellasValidasCasoLimite2()
        {
            DateTime desde = new DateTime(2024, 10, 03);
            DateTime hasta = new DateTime(2024, 11, 16);

            Promocion promo = new Promocion("", 0.10m, desde, hasta);
            Deposito depo = new Deposito(EnumArea.B, EnumTamano.Mediano, true, promo);
            Usuario user = new Usuario("Arnold", "Schwarzenegger", "Contr$en4", "rambo_xd@gmail.com");

            Valoracion valor = new Valoracion(5, "-", depo, user);

            Assert.AreEqual(5, valor.Estrellas);
            Assert.AreEqual("-", valor.Comentario);
            Assert.AreEqual(depo, valor.Deposito);
            Assert.AreEqual(user, valor.Usuario);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestEstrellasNoValidas1()
        {
            DateTime desde = new DateTime(2024, 02, 03);
            DateTime hasta = new DateTime(2024, 11, 16);

            Promocion promo = new Promocion("", 0.10m, desde, hasta);
            Deposito depo = new Deposito(EnumArea.B, EnumTamano.Mediano, true, promo);
            Usuario user = new Usuario("Pedro", "Porro", "Contr$en4", "gunners_999@outlook.com.nz");

            Valoracion valor = new Valoracion(666, "-", depo, user);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestEstrellasNoValidas2()
        {
            DateTime desde = new DateTime(2024, 02, 03);
            DateTime hasta = new DateTime(2024, 11, 16);

            Promocion promo = new Promocion("", 0.10m, desde, hasta);
            Deposito depo = new Deposito(EnumArea.B, EnumTamano.Mediano, true, promo);
            Usuario user = new Usuario("Antonio", "Berni", "Contr$en4", "juanito_laguna@gmail.com");

            Valoracion valor = new Valoracion(-666, "-", depo, user);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestEstrellasNoValidasLimite1()
        {
            DateTime desde = new DateTime(2024, 02, 03);
            DateTime hasta = new DateTime(2024, 11, 16);

            Promocion promo = new Promocion("", 0.10m, desde, hasta);
            Deposito depo = new Deposito(EnumArea.B, EnumTamano.Mediano, true, promo);
            Usuario user = new Usuario("Juanma", "Blanes", "Contr$en4", "patriota_33@vera.com.uy");

            Valoracion valor = new Valoracion(0, "-", depo, user);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestEstrellasNoValidasLimite2()
        {
            DateTime desde = new DateTime(2024, 02, 03);
            DateTime hasta = new DateTime(2024, 11, 16);

            Promocion promo = new Promocion("", 0.10m, desde, hasta);
            Deposito depo = new Deposito(EnumArea.B, EnumTamano.Mediano, true, promo);
            Usuario user = new Usuario("Skynet", "666", "Contr$en4", "robocop@gmail.com");

            Valoracion valor = new Valoracion(6, "-", depo, user);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestEstrellasNoValidasNegativas()
        {
            DateTime desde = new DateTime(2024, 02, 03);
            DateTime hasta = new DateTime(2024, 11, 16);

            Promocion promo = new Promocion("", 0.10m, desde, hasta);
            Deposito depo = new Deposito(EnumArea.B, EnumTamano.Mediano, true, promo);
            Usuario user = new Usuario("HAL", "NUEVEMIL", "Contr$en4696", "2001@gmail.com");

            Valoracion valor = new Valoracion(-6, "-", depo, user);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestComentarioNoValidoPorExtension()
        {
            DateTime desde = new DateTime(2024, 02, 03);
            DateTime hasta = new DateTime(2024, 11, 16);

            Promocion promo = new Promocion("", 0.10m, desde, hasta);
            Deposito depo = new Deposito(EnumArea.B, EnumTamano.Mediano, true, promo);
            Usuario user = new Usuario("Eric", "Cartman", "Contr$en4", "colorado_park@gmail.com");

            Valoracion valor = new Valoracion(3, "Lorem ipsum dolor sit amet, consectetur" +
                "adipiscing elit. Sed fermentum aliquam nisi, at fermentum justo vehicula" +
                "eget. Integer sed ipsum sit amet ligula dictum tincidunt. Sed sit amet dui" +
                "quam. Duis at ligula non metus vestibulum vehicula. Ut nec mi sed urna" +
                "volutpat bibendum. Nulla facilisi. Vestibulum ut purus id sapien pulvinar" +
                "vulputate. Vivamus aliquam sapien ac ex condimentum, ut tempor lacus vehicula." +
                "Vivamus dignissim enim sed eros vehicula luctus. Integer bibendum nulla sed" +
                "sagittis vulputate. Cras non odio sem. Duis laoreet eros eget sapien" +
                "facilisis, eget accumsan turpis auctor. Pellentesque habitant morbi tristique" +
                "senectus et netus et malesuada fames ac turpis egestas. Mauris pharetra eros" +
                "eget tortor bibendum, id feugiat libero fermentum. Curabitur sit amet arcu ut" +
                "mauris lacinia pharetra. Nunc quis malesuada nisi, vel auctor lacus.", depo, user);
        }

    }

}
