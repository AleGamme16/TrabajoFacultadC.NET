using Microsoft.VisualStudio.TestTools.UnitTesting;
using Backend;
using Assert = Microsoft.VisualStudio.TestTools.UnitTesting.Assert;

namespace Testing
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestVerificarMailSeaTrue()
        {
            Cliente cliente = new Cliente("nombre", "apellido", "contrasena", "alegamme16@gmail.com");
            bool res = cliente.verificarMail(cliente._email); 
            Assert.IsTrue(res);
        }
    }
}