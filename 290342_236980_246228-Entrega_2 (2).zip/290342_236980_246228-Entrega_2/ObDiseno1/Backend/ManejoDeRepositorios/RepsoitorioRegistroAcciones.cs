﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Backend.ManejoDeRepositorios
{
    public class RepositorioRegistroAcciones
    {
        private readonly MemoryDatabase _database;

        public  RepositorioRegistroAcciones(MemoryDatabase database)
        {
            _database = database;
        }

        public void AgregarRegistroAccion(string tipoAccion, Usuario usuario, DateTime fecha)
        {
            if (usuario == null) throw new ArgumentNullException(nameof(usuario));
            RegistroAccion registro= new RegistroAccion(tipoAccion,usuario.Nombre, usuario.Apellido,fecha);
           _database.Registros.Add(registro);
        }
        
        public List<RegistroAccion> ObtenerTodosLosRegistros()
        {
            return _database.Registros;
        }
    }
}
