INSERT INTO BddDiseno1.dbo.Depositos (Area,Tamano,Climatizado,PromocionId,Nombre) VALUES
	 (2,1,0,1,N'DepoC'),
	 (4,0,0,2,N'DepoCostaAzul'),
	 (0,2,0,3,N'DepoAmarillo'),
	 (3,2,0,2,N'DepoVerde'),
	 (0,2,0,3,N'DepoVioleta'),
	 (0,2,0,8,N'DepoGarage'),
	 (4,1,0,11,N'DepoParaMayores'),
	 (1,2,0,3,N'DepoParaMessi');
