INSERT INTO BddDiseno1.dbo.Usuarios (Nombre,Apellido,Contrasena,Mail,Rol,Discriminator) VALUES
	 (N'Alejandro',N'Gammella',N'@Ale1234',N'alegamme16@gmail.com',1,N'Administrador'),
	 (N'Marcos',N'Lopez',N'@Marcos123',N'marcos@hotmail.com',0,N'Cliente'),
	 (N'Lucas',N'Martinez',N'@Lucas123',N'Lucas@yahoo.com',0,N'Cliente'),
	 (N'Manuel',N'Moreira',N'@More1234',N'more09@gmail.com',0,N'Cliente'),
	 (N'Gabriel',N'Morales',N'Gabriel@14',N'gabi14@gmail.com',0,N'Cliente'),
	 (N'Alexander',N'Pop',N'@Alex12345',N'alex77@hotmail.com',0,N'Cliente');
