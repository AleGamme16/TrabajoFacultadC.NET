﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Backend.ManejoDeRepositorios
{
    public class RepositorioValoracion
    {
        private readonly MemoryDatabase _database;
        private readonly RepositorioRegistroAcciones _repositorioRegistro;

        public RepositorioValoracion(MemoryDatabase database, RepositorioRegistroAcciones repositorioRegistro)
        {
            _database = database;
            _repositorioRegistro = repositorioRegistro;
        }

        public void AgregarValoracion(Valoracion unaValoracion)
        {
            _repositorioRegistro.AgregarRegistroAccion("Creo una valoracion", unaValoracion.Usuario, DateTime.Now);
            _database.Valoraciones.Add(unaValoracion);
        }

        public bool ExisteValoracion(Valoracion unaValoracion)
        {
           return _database.Valoraciones.Contains(unaValoracion);
        }

        public void BorrarValoracion(Valoracion unaValoracion)
        {
            _database.Valoraciones.Remove(unaValoracion);
        }

    }
}
