﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Backend.ManejoDeRepositorios
{
    public class RepositorioDeposito
    {
        private readonly MemoryDatabase _database;

        public RepositorioDeposito(MemoryDatabase database)
        {
            _database = database;
        }

        public void AgregarDeposito(Deposito unDeposito)
        {
            _database.Depositos.Add(unDeposito);
        }

        public void BorrarDeposito(Deposito deposito)
        {
            _database.Depositos.Remove(deposito);
        }

        public bool ExisteDeposito(Deposito unDeposito)
        {
            return _database.Depositos.Contains(unDeposito);
        }

        public List<Deposito> ObtenerDepositos()
        {
            return _database.Depositos;

        }
        
        public Deposito RetornarDepositoPorId(int id)
        {
            foreach(var deposito in _database.Depositos)
            {
                if(deposito!=null && deposito.ID == id)
                {
                    return deposito;
                }
            }
            return null;
        }

    }

}
