﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Backend.ManejoDeRepositorios
{
    public class RepositorioPromocion
    {
        private readonly MemoryDatabase _database;

        public RepositorioPromocion(MemoryDatabase database)
        {
            _database = database;
        }

        public void AgregarPromocion(Promocion unaPromocion)
        {
            _database.Promociones.Add(unaPromocion);
        }

        public bool ExistePromocion(Promocion unaPromocion)
        {
            return _database.Promociones.Contains(unaPromocion);
        }

        public void BorrarPromocion(Promocion unaPromocion)
        {
            _database.Promociones.Remove(unaPromocion);
        }

        public List<Promocion> ObtenerPromociones()
        {
            return _database.Promociones;
        }

        public Promocion RetornarPromocionPorId(int id)
        {
            foreach(var promocion in _database.Promociones)
            {
                if (promocion.ID == id && promocion!=null)
                {
                    return promocion;
                }
            }
            return null;
        }

    }
}
