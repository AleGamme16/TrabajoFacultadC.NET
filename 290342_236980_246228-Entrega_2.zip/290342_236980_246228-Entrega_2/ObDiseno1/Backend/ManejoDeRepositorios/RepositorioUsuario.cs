﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Backend.ManejoDeRepositorios
{
    public class RepositorioUsuario
    {
        private readonly MemoryDatabase _database;

        public RepositorioUsuario(MemoryDatabase database)
        {
            _database = database;
        }

        public void AgregarUsuario(Usuario unUsuario)
        {
            _database.Usuarios.Add(unUsuario);
        }

        public bool ExisteUsuario(Usuario unUsuario)
        {
            return _database.Usuarios.Contains(unUsuario);
        }

        public void BorrarUsuario(Usuario unUsuario)
        {
            _database.Usuarios.Remove(unUsuario);
        }

        public bool ExisteUsuarioConEseMailYContrasena(string mailUsuario, string password)
        {
            foreach(var usuario in _database.Usuarios)
            {
                if (usuario.Mail == mailUsuario && usuario.Contrasena==password && usuario!=null)
                {
                    return true;
                }
            }
            return false;
        }

        public bool ExisteUsuarioConEseMail(string _mail)
        {
            foreach (var usuario in _database.Usuarios)
            {
                if (usuario.Mail == _mail)
                {
                    return true;
                }
            }
            return false;
        }

        public Usuario RetornarUsuario(string mailUsuario, string password)
        {
            foreach(var usuario in _database.Usuarios)
            {
                if (usuario.Mail==mailUsuario && usuario.Contrasena==password && usuario != null)
                {
                    return usuario;
                }
            }
            return null;
        }

        public void InicializarAdministrador(string nombre, string apellido, string password, string mail)
        {
            _database.Administrador = new Administrador(nombre, apellido, password, mail);
            _database.Administrador.Rol=EnumRol.Administrador;
        }

        public List<Usuario> ObtenerClientes()
        {
            return _database.Usuarios.Where(u => u.Rol == EnumRol.Cliente).ToList();
        }
    }
}
