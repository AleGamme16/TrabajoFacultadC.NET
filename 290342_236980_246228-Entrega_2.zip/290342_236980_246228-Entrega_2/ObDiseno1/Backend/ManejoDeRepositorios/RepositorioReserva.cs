﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Backend.ManejoDeRepositorios
{
    public class RepositorioReserva
    {
        private readonly MemoryDatabase _database;

        public RepositorioReserva(MemoryDatabase database)
        {
            _database = database;
        }

        public void AgregarReserva(Reserva unaReserva)
        {
            _database.Reservas.Add(unaReserva);
        }

        public void BorrarReserva(Reserva reserva)
        {
            _database.Reservas.Remove(reserva);
        }
        public bool ExisteReserva(Reserva unaReserva) 
        {
            return _database.Reservas.Contains(unaReserva);        
        }
        
        public Reserva RetornarReservaPorId(int id)
        {
            foreach(var reserva in _database.Reservas)
            {
                if (reserva.ID == id) { 
                    return reserva;
                }
                
            }
            return null;
        }

        public Deposito RetornarDepositoPorReservaId(int idDeDepositoEnReserva)
        {
            foreach(var reserva in _database.Reservas)
            {
                foreach(var deposito in _database.Depositos)
                {
                    if(reserva.Deposito.ID==deposito.ID)
                    {
                        return deposito;
                    }
                }
            }
            return null;
        }

        public List<Deposito> ObtenerDepositosNoReservados()
        {
            List<Deposito> depositosNoReservados = new List<Deposito>();

            foreach (var deposito in _database.Depositos)
            {
                bool estaReservado = _database.Reservas.Any(r => r.Deposito.ID == deposito.ID);
                if (!estaReservado)
                {
                    depositosNoReservados.Add(deposito);
                }
            }

            return depositosNoReservados;
        }

        public decimal CalcularIngresosPorAlquileres(DateTime fechaInicio, DateTime fechaFin)
        {
            decimal ingresos = 0;
            foreach (var reserva in _database.Reservas)
            {
                if (reserva.FechaInicio <= fechaFin && reserva.FechaFin >= fechaInicio)
                {
                    DateTime fechaInicioReserva = reserva.FechaInicio < fechaInicio ? fechaInicio : reserva.FechaInicio;
                    DateTime fechaFinReserva = reserva.FechaFin > fechaFin ? fechaFin : reserva.FechaFin;
                    TimeSpan duracionReserva = fechaFinReserva - fechaInicioReserva;
                    ingresos += reserva.Costo * (decimal)duracionReserva.TotalDays / (decimal)(reserva.FechaFin - reserva.FechaInicio).TotalDays;
                }
            }
            return ingresos;
        }



        public int ContarDepositosAlquilados(DateTime fechaInicio, DateTime fechaFin)
        {
            int cantidad = 0;
            foreach (var reserva in _database.Reservas)
            {
                if (reserva.FechaInicio >= fechaInicio && reserva.FechaFin <= fechaFin)
                {
                    cantidad++;
                }
            }
            return cantidad;
        }

        public Dictionary<EnumArea, decimal> CalcularIngresosPorAlquileresPorZona(DateTime fechaInicio, DateTime fechaFin)
        {
            Dictionary<EnumArea, decimal> ingresosPorZona = new Dictionary<EnumArea, decimal>();

            foreach (var reserva in _database.Reservas)
            {
                if (reserva.FechaInicio <= fechaFin && reserva.FechaFin >= fechaInicio)
                {
                    decimal ingresosReserva = reserva.Costo * (decimal)(reserva.FechaFin - reserva.FechaInicio).TotalDays;
                    if (ingresosPorZona.ContainsKey(reserva.Deposito.Area))
                    {
                        ingresosPorZona[reserva.Deposito.Area] += ingresosReserva;
                    }
                    else
                    {
                        ingresosPorZona[reserva.Deposito.Area] = ingresosReserva;
                    }
                }
            }

            return ingresosPorZona;
        }

        public Dictionary<EnumArea, int> ContarDepositosAlquiladosPorZona(DateTime fechaInicio, DateTime fechaFin)
        {
            Dictionary<EnumArea, int> cantidadDepositosPorZona = new Dictionary<EnumArea, int>();

            foreach (var reserva in _database.Reservas)
            {
                if (reserva.FechaInicio <= fechaFin && reserva.FechaFin >= fechaInicio)
                {
                    if (cantidadDepositosPorZona.ContainsKey(reserva.Deposito.Area))
                    {
                        cantidadDepositosPorZona[reserva.Deposito.Area]++;
                    }
                    else
                    {
                        cantidadDepositosPorZona[reserva.Deposito.Area] = 1;
                    }
                }
            }

            return cantidadDepositosPorZona;
        }


    }

}
