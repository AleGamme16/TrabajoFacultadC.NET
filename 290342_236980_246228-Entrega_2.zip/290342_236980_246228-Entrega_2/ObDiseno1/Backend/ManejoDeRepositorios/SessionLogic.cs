﻿using Backend.ManejoDeRepositorios;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Backend.ManejoDeRepositorios
{
    public class SessionLogic
    {
        private readonly RepositorioUsuario _repositorioUsuario;
        private readonly RepositorioRegistroAcciones _repositorioRegistro;

        public Usuario UsuarioActual { get;  set; }
        public Cliente ClienteActual { get;  set; }

        public SessionLogic(RepositorioUsuario repositorioUsuario, RepositorioRegistroAcciones repositorioRegistro)
        {
            _repositorioUsuario = repositorioUsuario;
            _repositorioRegistro = repositorioRegistro;
        }

        public bool ValidarCredenciales(string username, string password)
        {
            Usuario user = _repositorioUsuario.RetornarUsuario(username, password);
            if (user != null)
            {
                UsuarioActual = user;
                return true;
            }
            return false;
        }

        public void LoginCliente(Cliente cliente)
        {
            ClienteActual = cliente;
            ClienteActual.Rol = EnumRol.Cliente;
            if (ClienteActual != null && cliente.Rol == EnumRol.Cliente)
            {
                _repositorioRegistro.AgregarRegistroAccion("Inicio sesión", cliente, DateTime.Now);
            }
        }
        public void LoginAdmin(Usuario user)
        {
            UsuarioActual = user;
            UsuarioActual.Rol = EnumRol.Administrador;
        }

        public void Logout()
        {
            if(ClienteActual!=null && ClienteActual.Rol == EnumRol.Cliente)
            {
                _repositorioRegistro.AgregarRegistroAccion("Cerró sesión", ClienteActual, DateTime.Now);
            }

            UsuarioActual = null;
            ClienteActual = null;
        }
    }
}

