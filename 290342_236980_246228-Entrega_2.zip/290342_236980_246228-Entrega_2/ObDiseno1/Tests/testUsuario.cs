using Backend;
using Backend.Context;
using Backend.Services;
using Backend.SQL;
using Microsoft.EntityFrameworkCore;

namespace Tests
{
    [TestClass]
    public class TestUsuario
    {
        private ServicioUsuario _servicioUsuario;

        [TestInitialize]
        public void SetUp()
        {
            // Crear una instancia real de SqlRepositorioUsuario con una base de datos en memoria
            var options = new DbContextOptionsBuilder<AppDataContext>()
                .UseInMemoryDatabase(databaseName: "TestDatabase")
                .Options;

            var context = new AppDataContext(options);
            var repositorioUsuario = new SqlRepositorioUsuario(context);

            _servicioUsuario = new ServicioUsuario(repositorioUsuario);
        }

        [TestMethod]
        public void TestCrearUsuarioSinParametros()
        {
            Usuario user = new Usuario();

            Assert.AreEqual("no", user.Nombre);
            Assert.AreEqual("name", user.Apellido);
            Assert.AreEqual("no_email@gmail.com", user.Mail);
            Assert.AreEqual("NoPa$$w0rd", user.Contrasena);
            Assert.AreEqual(9999, user.ID);
        }

        [TestMethod]
        public void TestCrearUsuarioConParametrosTodoValido()
        {
            Usuario user = new Usuario("Rodrigo", "Corral", "ConPa$$w0d", "rodrigocorral20@outlook.com");

            Assert.AreEqual("Rodrigo", user.Nombre);
            Assert.AreEqual("Corral", user.Apellido);
            Assert.AreEqual("rodrigocorral20@outlook.com", user.Mail);
            Assert.AreEqual("ConPa$$w0d", user.Contrasena);
            //Assert.AreEqual(Usuario.ContadorDeID, user.ID);
        }

        [TestMethod]
        public void TestCrearUsuarioTodoValido()
        {
            Usuario user = new Usuario("Alejandro", "Gamella", "Pa$$w0rdD", "alegamme16@gmail.com");

            Assert.AreEqual("Alejandro", user.Nombre);
            Assert.AreEqual("Gamella", user.Apellido);
            Assert.AreEqual("alegamme16@gmail.com", user.Mail);
            Assert.AreEqual("Pa$$w0rdD", user.Contrasena);
            //Assert.AreEqual(Usuario.ContadorDeID, user.ID);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestNombreYApellidoNoValidoPorExtension()
        {
            Usuario usuario = new Usuario("123243455667789909021213344556778678990122334456567788991223354566788990122133445656778089890342", "3456767856754334sdfhdghdfgdhgfdhgfdhdfdghjjhkkjllkasdSDAFDFSGGFHGHJJKLHLSADDSFADFGGHFJHJKKLLKDSADSFFDGHGHJJKHJKLGFDSADFFDG" +
                "RTEGUJRGFDFDGF DDFGFDSGGFJHJHKKLJHJGGDFSFDSAFDGSFDGSDFSGFHDDFGSFDGHFSDTGDHFDSGFFHDSDSGRGFHDRGDSHFGDSGFDSFGDSDFHGS", "PAs$$w0rd", "123485@gmail.com");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestNombreNoValidoSinLetras()
        {
            Usuario usuario = new Usuario("12345", "Aguirre", "PAs$$w0rd", "123485@gmail.com");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestApellidoNoValidoSinLetras()
        {
            Usuario usuario = new Usuario("Luis", "777", "PAs$$w0rd", "123485@gmail.com");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestVerificarMailNoValido1()
        {
            Usuario usuario = new Usuario("nombre", "apellido", "PAs$$w0rd", "@mama.com");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestVerificarMailNoValidoPorExtension()
        {
            Usuario usuario = new Usuario("nombre", "apellido", "PAs$$w0rd", "123454657891234566890'0'1234576890853223456789865432234e57898765435788654345676545654875467456785647878564785647843724583543785437878543785437854378543785437854378578437854378543785437854378543785478543785437854378574385748357843578785@gmail.com");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestVerificarMailNoValidoPorFormato()
        {
            Usuario usuario = new Usuario("nombre", "apellido", "PAs$$w0rd", "211olakease");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestVerificarMailNoValidoSinArroba()
        {
            Usuario usuario = new Usuario("nombre", "apellido", "PAs$$w0rd", "12345465789.com");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestVerificarMailNoValidoFormatoMal()
        {
            Usuario usuario = new Usuario("nombre", "apellido", "PAs$$w0rd", "olakeaxe.com@");
        }

        [TestMethod]
        public void TestContrasenaValida()
        {
            Usuario user = new Usuario("nombre", "apellido", "@Contrasena666", "asdfgh_69@vera.com");

            Assert.AreEqual("nombre", user.Nombre);
            Assert.AreEqual("apellido", user.Apellido);
            Assert.AreEqual("asdfgh_69@vera.com", user.Mail);
            Assert.AreEqual("@Contrasena666", user.Contrasena);
            //Assert.AreEqual(Usuario.ContadorDeID, user.ID);
        }

        [TestMethod]
        public void TestContrasenaCasoLimiteValido()
        {
            Usuario user = new Usuario("nombre", "apellido", "Contr@44", "asereje@gmail.com");

            Assert.AreEqual("nombre", user.Nombre);
            Assert.AreEqual("apellido", user.Apellido);
            Assert.AreEqual("asereje@gmail.com", user.Mail);
            Assert.AreEqual("Contr@44", user.Contrasena);
            //Assert.AreEqual(Usuario.ID, user.ID);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestContrasenaNoValidaCasoLimitePorExtension()
        {
            Usuario usuario = new Usuario("nombre", "apellido", "Contr@4", "asereje@gmail.com");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestContrasenaNoValidaSinCharEspecial()
        {
            Usuario usuario = new Usuario("nombre", "apellido", "Contr56asA4", "asereje@gmail.com");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestContrasenaNoValidaSinMayus()
        {
            Usuario usuario = new Usuario("nombre", "apellido", "c%ontr56544", "asereje@gmail.com");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestContrasenaNoValidaSinNumero()
        {
            Usuario usuario = new Usuario("nombre", "apellido", "CONTRASENA$%", "asereje@gmail.com");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestContrasenaNoValidaSinMinus()
        {
            Usuario usuario = new Usuario("nombre", "apellido", "C%ONTRAS56544", "asereje@gmail.com");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestContrasenaNoValidaPorExtension()
        {
            Usuario usuario = new Usuario("nombre", "apellido", "C", "asereje@gmail.com");
        }

        [TestMethod]
        public void TestContrasenaValida2()
        {
            Usuario usuario = new Usuario("nombre", "apellido", "@Contrasena111", "alegamme16@gmail.com");
            string contraValida = "@Contrasena111";
            bool res = _servicioUsuario.VerificarSegundaContra(usuario.Contrasena, contraValida);
            Assert.IsTrue(res);
        }

        [TestMethod]
        public void TestContrasenaNoValida2()
        {
            Usuario usuario = new Usuario("nombre", "apellido", "@Contrasena111", "alegamme16@gmail.com");
            string contraNoValida = "@Contrasena112";
            bool res = _servicioUsuario.VerificarSegundaContra(usuario.Contrasena, contraNoValida);
            Assert.IsFalse(res);
        }

        [TestMethod]
        public void TestValidarNombre_NombreValido_SinCaracteresEspeciales()
        {
            string nombre = "Alejandro";
            bool resultado = _servicioUsuario.ValidarNombreOApellido(nombre);
            Assert.IsTrue(resultado);
        }

        [TestMethod]
        public void TestValidarNombre_NombreInvalido_ConCaracteresEspeciales()
        {
            string nombre = "@leja.ndro";
            bool resultado = _servicioUsuario.ValidarNombreOApellido(nombre);
            Assert.IsFalse(resultado);
        }

        [TestMethod]
        public void TestValidarNombre_NombreInvalido_ConDosPuntosConsecutivos()
        {
            string nombre = "Juan..ito";
            bool resultado = _servicioUsuario.ValidarNombreOApellido(nombre);
            Assert.IsFalse(resultado);
        }

        [TestMethod]
        public void TestValidarNombre_NombreInvalido_ConPuntoAlFinal()
        {
            string nombre = "Mar�a.";
            bool resultado = _servicioUsuario.ValidarNombreOApellido(nombre);
            Assert.IsFalse(resultado);
        }

        [TestMethod]
        public void TestValidarNombre_NombreInvalido_ConPuntoAlInicio()
        {
            string nombre = ".Pedro";
            bool resultado = _servicioUsuario.ValidarNombreOApellido(nombre);
            Assert.IsFalse(resultado);
        }
    }
}
