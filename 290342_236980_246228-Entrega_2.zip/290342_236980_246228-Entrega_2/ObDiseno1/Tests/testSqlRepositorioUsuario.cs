﻿using System;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Backend.SQL;
using Backend;
using Backend.Context;
using Backend.Services;

namespace Tests
{
    [TestClass]
    public class TestSqlRepositorioUsuario
    {
        private SqlRepositorioUsuario _repositoryUsuario;
        private ServicioUsuario _servicioUsuario;
        private AppDataContext _context;
        private readonly IAppContextFactory _contextFactory = new MemoryAppContext();

        [TestInitialize]
        public void SetUp()
        {
            _context = _contextFactory.CreateDbContext();
            _repositoryUsuario = new SqlRepositorioUsuario(_context);
            _servicioUsuario = new ServicioUsuario(_repositoryUsuario);
        }

        [TestCleanup]
        public void CleanUp()
        {
            _context.Database.EnsureDeleted();
        }

        [TestMethod]
        public void Test_GetAll_RetornaTodosUsuarios()
        {
            var usuario = new Usuario
            {
                ID = 1,
                Nombre = "John",
                Apellido = "Doe",
                Contrasena = "Password123!",
                Mail = "john.doe@example.com",
                Rol = EnumRol.Cliente
            };

            _context.Usuarios.Add(usuario);
            _context.SaveChanges();

            var usuariosInDb = _servicioUsuario.TraerListaUsuarios();

            Assert.IsTrue(usuariosInDb.Contains(usuario));
            Assert.AreEqual(1, usuariosInDb.Count());
        }

        [TestMethod]
        public void Test_AgregarUsuario()
        {
            var usuario = new Usuario
            {
                ID = 1,
                Nombre = "John",
                Apellido = "Doe",
                Contrasena = "Password123!",
                Mail = "john.doe@example.com",
                Rol = EnumRol.Cliente
            };

            _servicioUsuario.AgregarUsuario(usuario);

            var usuarioInDb = _context.Usuarios.First();
            Assert.AreEqual(usuario, usuarioInDb);
        }

        [TestMethod]
        public void Test_EncontrarUsuarioPorId()
        {
            var usuario = new Usuario
            {
                ID = 232,
                Nombre = "John",
                Apellido = "Doe",
                Contrasena = "Password123!",
                Mail = "john.doe@example.com",
                Rol = EnumRol.Cliente
            };

            _context.Usuarios.Add(usuario);
            _context.SaveChanges();

            //var usuarioInDb = _servicioUsuario.EncontrarUsuarioPorId(usuario.ID);

            //Assert.AreEqual(usuario, usuarioInDb);
        }

        [TestMethod]
        public void Test_ActualizarUsuario()
        {
            var usuario = new Usuario
            {
                Nombre = "Jane",
                Apellido = "Doe",
                Contrasena = "Password123!",
                Mail = "jane.doe@example.com",
                Rol = EnumRol.Cliente
            };

            _context.Usuarios.Add(usuario);
            _context.SaveChanges();

            usuario.Nombre = "Jane Updated";
            _servicioUsuario.ActualizarUsuario(usuario);

            var usuarioInDb = _context.Usuarios.FirstOrDefault(u => u.Mail == "jane.doe@example.com");
            Assert.IsNotNull(usuarioInDb);
            Assert.AreEqual("Jane Updated", usuarioInDb.Nombre);
        }

        [TestMethod]
        public void Test_EliminarUsuario()
        {
            var usuario = new Usuario
            {
                Nombre = "Jane",
                Apellido = "Doe",
                Contrasena = "Password123!",
                Mail = "jane.doe@example.com",
                Rol = EnumRol.Cliente
            };

            _context.Usuarios.Add(usuario);
            _context.SaveChanges();

            _servicioUsuario.EliminarUsuario(usuario.ID);

            var usuarioInDb = _context.Usuarios.FirstOrDefault(u => u.Mail == "jane.doe@example.com");
            Assert.IsNull(usuarioInDb);
        }

        [TestMethod]
        public void Test_ExisteUsuarioConEseMailYContrasena()
        {
            var usuario = new Usuario
            {
                Nombre = "John",
                Apellido = "Doe",
                Contrasena = "Password123!",
                Mail = "john.doe@example.com",
                Rol = EnumRol.Cliente
            };
            _context.Usuarios.Add(usuario);
            _context.SaveChanges();

            var existe = _servicioUsuario.ExisteUsuarioConEseMailYContrasena(usuario.Mail, usuario.Contrasena);

            Assert.IsTrue(existe);
        }

        [TestMethod]
        public void Test_ExisteUsuarioConEseMail()
        {
            var usuario = new Usuario
            {
                Nombre = "John",
                Apellido = "Doe",
                Contrasena = "Password123!",
                Mail = "john.doe@example.com",
                Rol = EnumRol.Cliente
            };
            _context.Usuarios.Add(usuario);
            _context.SaveChanges();

            var existe = _servicioUsuario.ExisteUsuarioConEseMail(usuario.Mail);

            Assert.IsTrue(existe);
        }

        [TestMethod]
        public void Test_RetornarUsuarioPorContrasena()
        {
            var usuario = new Usuario
            {
                Nombre = "John",
                Apellido = "Doe",
                Contrasena = "Password123!",
                Mail = "john.doe@example.com",
                Rol = EnumRol.Cliente
            };
            _context.Usuarios.Add(usuario);
            _context.SaveChanges();

            //var usuarioInDb = _servicioUsuario.RetornarUsuarioPorContrasena(usuario.Mail, usuario.Contrasena);

            //Assert.AreEqual(usuario, usuarioInDb);
        }

        [TestMethod]
        public void Test_InicializarAdministrador()
        {
            var nombre = "Admin";
            var apellido = "Admin";
            var password = "Admin123!";
            var mail = "admin@example.com";

            _servicioUsuario.InicializarAdministrador(nombre, apellido, password, mail);

            var adminInDb = _context.Usuarios.FirstOrDefault(u => u.Mail == mail);
            Assert.IsNotNull(adminInDb);
            Assert.AreEqual(EnumRol.Administrador, adminInDb.Rol);
        }

        [TestMethod]
        public void Test_ObtenerClientes()
        {
            var cliente = new Usuario
            {
                Nombre = "John",
                Apellido = "Doe",
                Contrasena = "Password123!",
                Mail = "john.doe@example.com",
                Rol = EnumRol.Cliente
            };
            _context.Usuarios.Add(cliente);
            _context.SaveChanges();

            var clientes = _servicioUsuario.ObtenerClientes();

            Assert.IsTrue(clientes.Contains(cliente));
        }
    }
}

