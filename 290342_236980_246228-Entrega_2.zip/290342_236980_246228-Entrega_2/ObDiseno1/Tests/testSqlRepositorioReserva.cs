﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Backend.SQL;
using Backend;
using Backend.Context;
using System.Linq;
using System;
using Backend.ManejoDeRepositorios;

namespace Tests
{
    [TestClass]
    public class testSqlRepositorioReserva
    {
        private SqlRepositorioReserva _repositoryReserva;
        private AppDataContext _context;
        private readonly IAppContextFactory _contextFactory = new MemoryAppContext();

        [TestInitialize]
        public void SetUp()
        {
            _context = _contextFactory.CreateDbContext();
            _repositoryReserva = new SqlRepositorioReserva(_context);
        }

        [TestCleanup]
        public void CleanUp()
        {
            _context.Database.EnsureDeleted();
        }

        [TestMethod]
        public void test_ObtenerReservas_retornarTodasLasReservas()
        {
            var reserva = new Reserva
            {
                Cliente = new Cliente { Nombre = "John Doe" },
                FechaInicio = DateTime.Today,
                FechaFin = DateTime.Today.AddDays(7),
                Costo = 1000,
                Estado = EnumEstado.Pendiente,
                MotivoRechazo = "",
                Deposito = new Deposito { Area = EnumArea.A, Tamano = EnumTamano.Pequeno, Climatizado = true }
            };

            _context.Reservas.Add(reserva);
            _context.SaveChanges();

            var reservasInDb = _repositoryReserva.ObtenerReservas();

            Assert.IsTrue(reservasInDb.Contains(reserva));
            Assert.AreEqual(1, reservasInDb.Count());
        }

        [TestMethod]
        public void test_AgregarReserva()
        {
            var reserva = new Reserva
            {
                Cliente = new Cliente { Nombre = "John Doe" },
                FechaInicio = DateTime.Today,
                FechaFin = DateTime.Today.AddDays(7),
                Costo = 1000,
                Estado = EnumEstado.Pendiente,
                MotivoRechazo = "",
                Deposito = new Deposito { Area = EnumArea.A, Tamano = EnumTamano.Pequeno, Climatizado = true }
            };

            _repositoryReserva.AgregarReserva(reserva);

            var reservaInDb = _context.Reservas.First();
            Assert.AreEqual(reserva, reservaInDb);
        }

        [TestMethod]
        public void test_RetornarReservaPorId()
        {
            var reserva = new Reserva
            {
                Cliente = new Cliente { Nombre = "John Doe" },
                FechaInicio = DateTime.Today,
                FechaFin = DateTime.Today.AddDays(7),
                Costo = 1000,
                Estado = EnumEstado.Pendiente,
                MotivoRechazo = "",
                Deposito = new Deposito { Area = EnumArea.A, Tamano = EnumTamano.Pequeno, Climatizado = true }
            };

            _context.Reservas.Add(reserva);
            _context.SaveChanges();

            //var reservaInDb = _repositoryReserva.RetornarReservaPorId(reserva.ID);

            //Assert.AreEqual(reserva, reservaInDb);
        }

        [TestMethod]
        public void test_BorrarReserva()
        {
            var reserva = new Reserva
            {
                Cliente = new Cliente { Nombre = "John Doe" },
                FechaInicio = DateTime.Today,
                FechaFin = DateTime.Today.AddDays(7),
                Costo = 1000,
                Estado = EnumEstado.Pendiente,
                MotivoRechazo = "",
                Deposito = new Deposito { Area = EnumArea.A, Tamano = EnumTamano.Pequeno, Climatizado = true }
            };

            _context.Reservas.Add(reserva);
            _context.SaveChanges();

            _repositoryReserva.BorrarReserva(reserva);

            var reservasInDb = _repositoryReserva.ObtenerReservas();
            Assert.IsFalse(reservasInDb.Contains(reserva));
            Assert.AreEqual(0, reservasInDb.Count());
        }

        [TestMethod]
        public void test_ExisteReserva()
        {
            var reserva = new Reserva
            {
                Cliente = new Cliente { Nombre = "John Doe" },
                FechaInicio = DateTime.Today,
                FechaFin = DateTime.Today.AddDays(7),
                Costo = 1000,
                Estado = EnumEstado.Pendiente,
                MotivoRechazo = "",
                Deposito = new Deposito { Area = EnumArea.A, Tamano = EnumTamano.Pequeno, Climatizado = true }
            };

            _context.Reservas.Add(reserva);
            _context.SaveChanges();

            var existe = _repositoryReserva.ExisteReserva(reserva);

            Assert.IsTrue(existe);
        }

        [TestMethod]
        public void test_RetornarDepositoPorReservaId()
        {
            // Arrange
            var deposito = new Deposito { Area = EnumArea.A, Tamano = EnumTamano.Pequeno, Climatizado = true };

            _context.Depositos.Add(deposito);
            _context.SaveChanges();

            var cliente = new Cliente { Nombre = "John", Apellido = "Doe", Contrasena = "Password123!", Mail = "john.doe@example.com" };

            var reserva = new Reserva
            {
                Cliente = cliente,
                FechaInicio = DateTime.Now.AddDays(1),
                FechaFin = DateTime.Now.AddDays(14),
                Costo = 3300,
                Estado = EnumEstado.Pendiente,
                MotivoRechazo = "",
                Deposito = deposito
            };

            _context.Reservas.Add(reserva);
            _context.SaveChanges();

            // Act
            var depositoInDb = _repositoryReserva.RetornarDepositoPorReservaId(reserva.ID);

            // Assert
            Assert.AreEqual(deposito, depositoInDb);
        }

        [TestMethod]
        public void test_ObtenerDepositosNoReservados()
        {
            // Resetea el contador de ID antes de crear las instancias
            Deposito.ContadorDeID = 0;

            // Arrange
            var deposito1 = new Deposito { Area = EnumArea.A, Tamano = EnumTamano.Pequeno, Climatizado = false };
            var deposito2 = new Deposito { Area = EnumArea.B, Tamano = EnumTamano.Mediano, Climatizado = true };
            var deposito3 = new Deposito { Area = EnumArea.C, Tamano = EnumTamano.Grande, Climatizado = false };

            _context.Depositos.Add(deposito1);
            _context.Depositos.Add(deposito2);
            _context.Depositos.Add(deposito3);
            _context.SaveChanges();

            var cliente = new Cliente { Nombre = "John", Apellido = "Doe", Contrasena = "Password123!", Mail = "john.doe@example.com" };

            var reserva = new Reserva
            {
                Cliente = cliente,
                FechaInicio = DateTime.Now.AddDays(1),
                FechaFin = DateTime.Now.AddDays(14),
                Costo = 3300,
                Estado = EnumEstado.Pendiente,
                MotivoRechazo = "",
                Deposito = deposito1
            };

            _context.Reservas.Add(reserva);
            _context.SaveChanges();

            // Act
            var depositosNoReservados = _repositoryReserva.ObtenerDepositosNoReservados();

            // Assert
            Assert.IsTrue(depositosNoReservados.Contains(deposito2));
            Assert.IsTrue(depositosNoReservados.Contains(deposito3));
            Assert.IsFalse(depositosNoReservados.Contains(deposito1));
        }

        //[TestMethod]
        //public void Test_AprobarYConfirmarReserva()
        //{
        //    // Arrange
        //    var reserva = new Reserva(new Cliente(), DateTime.Now, DateTime.Now.AddDays(1), 100, EnumEstado.Pendiente, string.Empty, new Deposito());
        //    _context.Reservas.Add(reserva);
        //    _context.SaveChanges();

        //    // Act
        //    _repositoryReserva.AprobarYConfirmarReserva(reserva.ID);

        //    // Assert
        //    var reservaInDb = _context.Reservas.FirstOrDefault(r => r.ID == reserva.ID);
        //    Assert.IsNotNull(reservaInDb);
        //    Assert.AreEqual(EnumEstado.Aprobada, reservaInDb.Estado);
        //    Assert.AreEqual(EnumEstadoPago.Capturado, reservaInDb.EstadoPago);
        //}

        //[TestMethod]
        //[ExpectedException(typeof(InvalidOperationException))]
        //public void Test_AprobarYConfirmarReserva_InvalidEstado()
        //{
        //    // Arrange
        //    var reserva = new Reserva(new Cliente(), DateTime.Now, DateTime.Now.AddDays(1), 100, EnumEstado.Aprobada, string.Empty, new Deposito());
        //    _context.Reservas.Add(reserva);
        //    _context.SaveChanges();

        //    // Act
        //    _repositoryReserva.AprobarYConfirmarReserva(reserva.ID);
        //}

        //[TestMethod]
        //public void Test_RechazarSolicitud()
        //{
        //    // Arrange
        //    var reserva = new Reserva(new Cliente(), DateTime.Now, DateTime.Now.AddDays(1), 100, EnumEstado.Pendiente, string.Empty, new Deposito());
        //    _context.Reservas.Add(reserva);
        //    _context.SaveChanges();

        //    // Act
        //    _repositoryReserva.RechazarSolicitud(reserva.ID, "Motivo de rechazo");

        //    // Assert
        //    var reservaInDb = _context.Reservas.FirstOrDefault(r => r.ID == reserva.ID);
        //    Assert.IsNotNull(reservaInDb);
        //    Assert.AreEqual(EnumEstado.Rechazada, reservaInDb.Estado);
        //    Assert.AreEqual("Motivo de rechazo", reservaInDb.MotivoRechazo);
        //}

        //[TestMethod]
        //[ExpectedException(typeof(InvalidOperationException))]
        //public void Test_RechazarSolicitud_InvalidEstado()
        //{
        //    // Arrange
        //    var reserva = new Reserva(new Cliente(), DateTime.Now, DateTime.Now.AddDays(1), 100, EnumEstado.Aprobada, string.Empty, new Deposito());
        //    _context.Reservas.Add(reserva);
        //    _context.SaveChanges();

        //    // Act
        //    _repositoryReserva.RechazarSolicitud(reserva.ID, "Motivo de rechazo");
        //}

        //[TestMethod]
        //[ExpectedException(typeof(ArgumentNullException))]
        //public void Test_RechazarSolicitud_SinMotivo()
        //{
        //    // Arrange
        //    var reserva = new Reserva(new Cliente(), DateTime.Now, DateTime.Now.AddDays(1), 100, EnumEstado.Pendiente, string.Empty, new Deposito());
        //    _context.Reservas.Add(reserva);
        //    _context.SaveChanges();

        //    // Act
        //    _repositoryReserva.RechazarSolicitud(reserva.ID, null);
        //}

        //[TestMethod]
        //[ExpectedException(typeof(ArgumentOutOfRangeException))]
        //public void Test_RechazarSolicitud_MotivoLargo()
        //{
        //    // Arrange
        //    var motivoLargo = new string('a', 301);
        //    var reserva = new Reserva(new Cliente(), DateTime.Now, DateTime.Now.AddDays(1), 100, EnumEstado.Pendiente, motivoLargo, new Deposito());
        //    _context.Reservas.Add(reserva);
        //    _context.SaveChanges();

        //    // Act
        //    _repositoryReserva.RechazarSolicitud(reserva.ID, motivoLargo);
        //}
    }
}
