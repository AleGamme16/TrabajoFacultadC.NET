﻿using Backend;
using Backend.Context;
using Backend.SQL;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Linq;

namespace Tests
{
    [TestClass]
    public class testSqlRepositorioPromocion
    {
        private SqlRepositorioPromocion _repositoryPromocion;
        private AppDataContext _context;
        private readonly IAppContextFactory _contextFactory = new MemoryAppContext();

        [TestInitialize]
        public void SetUp()
        {
            _context = _contextFactory.CreateDbContext();
            _repositoryPromocion = new SqlRepositorioPromocion(_context);
        }

        [TestCleanup]
        public void CleanUp()
        {
            _context.Database.EnsureDeleted();
        }

        [TestMethod]
        public void test_AgregarPromocion()
        {
            // Arrange
            var promocion = new Promocion
            {
                Etiqueta = "Promo1",
                Descuento = 0.1m,
                Desde = DateTime.Today,
                Hasta = DateTime.Today.AddDays(7)
            };

            // Act
            _repositoryPromocion.AgregarPromocion(promocion);

            // Assert
            var promocionInDb = _context.Promociones.First();
            Assert.AreEqual(promocion, promocionInDb);
        }

        [TestMethod]
        public void test_ExistePromocion()
        {
            // Arrange
            var promocion = new Promocion
            {
                Etiqueta = "Promo1",
                Descuento = 0.1m,
                Desde = DateTime.Today,
                Hasta = DateTime.Today.AddDays(7)
            };

            _context.Promociones.Add(promocion);
            _context.SaveChanges();

            // Act
            var exists = _repositoryPromocion.ExistePromocion(promocion);

            // Assert
            Assert.IsTrue(exists);
        }

        [TestMethod]
        public void test_BorrarPromocion()
        {
            // Arrange
            var promocion = new Promocion
            {
                Etiqueta = "Promo1",
                Descuento = 0.1m,
                Desde = DateTime.Today,
                Hasta = DateTime.Today.AddDays(7)
            };

            _context.Promociones.Add(promocion);
            _context.SaveChanges();

            // Act
            _repositoryPromocion.BorrarPromocion(promocion);

            // Assert
            var promocionInDb = _context.Promociones.FirstOrDefault(p => p.ID == promocion.ID);
            Assert.IsNull(promocionInDb);
        }

        [TestMethod]
        public void test_ObtenerPromociones()
        {
            // Arrange
            var promocion1 = new Promocion
            {
                Etiqueta = "Promo1",
                Descuento = 0.1m,
                Desde = DateTime.Today,
                Hasta = DateTime.Today.AddDays(7)
            };
            var promocion2 = new Promocion
            {
                Etiqueta = "Promo2",
                Descuento = 0.2m,
                Desde = DateTime.Today.AddDays(1),
                Hasta = DateTime.Today.AddDays(8)
            };

            _context.Promociones.Add(promocion1);
            _context.Promociones.Add(promocion2);
            _context.SaveChanges();

            // Act
            var promocionesInDb = _repositoryPromocion.ObtenerPromociones();

            // Assert
            Assert.AreEqual(2, promocionesInDb.Count);
            Assert.IsTrue(promocionesInDb.Contains(promocion1));
            Assert.IsTrue(promocionesInDb.Contains(promocion2));
        }

        [TestMethod]
        public void test_RetornarPromocionPorId()
        {
            // Arrange
            var promocion = new Promocion
            {
                Etiqueta = "Promo1",
                Descuento = 0.1m,
                Desde = DateTime.Today,
                Hasta = DateTime.Today.AddDays(7)
            };

            _context.Promociones.Add(promocion);
            _context.SaveChanges();

            // Act
            var promocionInDb = _repositoryPromocion.RetornarPromocionPorId(promocion.ID);

            // Assert
            Assert.AreEqual(promocion, promocionInDb);
        }
    }
}
