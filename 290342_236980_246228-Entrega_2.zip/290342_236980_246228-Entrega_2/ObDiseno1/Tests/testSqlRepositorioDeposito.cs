﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Backend.SQL;
using Backend;
using Backend.Context;
using System.Linq;

namespace Tests
{
    [TestClass]
    public class testSqlRepositorioDeposito
    {
        private SqlRepositorioDeposito _repositoryDeposito;
        private AppDataContext _context;
        private readonly IAppContextFactory _contextFactory = new MemoryAppContext();

        [TestInitialize]
        public void SetUp()
        {
            _context = _contextFactory.CreateDbContext();
            _repositoryDeposito = new SqlRepositorioDeposito(_context);
        }

        [TestCleanup]
        public void CleanUp()
        {
            _context.Database.EnsureDeleted();
        }

        [TestMethod]
        public void test_ObtenerDepositos_retornarTodosLosDepositos()
        {
            var deposito = new Deposito
            {
                ID = 1,
                Area = EnumArea.A,
                Tamano = EnumTamano.Pequeno,
                Climatizado = true
            };

            _context.Depositos.Add(deposito);
            _context.SaveChanges();

            var depositosInDb = _repositoryDeposito.ObtenerDepositos();

            Assert.IsTrue(depositosInDb.Contains(deposito));
            Assert.AreEqual(1, depositosInDb.Count());
        }

        [TestMethod]
        public void test_AgregarDeposito()
        {
            var deposito = new Deposito
            {
                ID = 1,
                Area = EnumArea.A,
                Tamano = EnumTamano.Pequeno,
                Climatizado = true
            };

            _repositoryDeposito.AgregarDeposito(deposito);

            var depositoInDb = _context.Depositos.First();
            Assert.AreEqual(deposito, depositoInDb);
        }

        [TestMethod]
        public void test_RetornarDepositoPorId()
        {
            var deposito = new Deposito
            {
                ID = 1,
                Area = EnumArea.A,
                Tamano = EnumTamano.Pequeno,
                Climatizado = true
            };

            _context.Depositos.Add(deposito);
            _context.SaveChanges();

            var depositoInDb = _repositoryDeposito.RetornarDepositoPorId(deposito.ID);

            Assert.AreEqual(deposito, depositoInDb);
        }

        [TestMethod]
        public void test_BorrarDeposito()
        {
            var deposito = new Deposito
            {
                ID = 1,
                Area = EnumArea.A,
                Tamano = EnumTamano.Pequeno,
                Climatizado = true
            };

            _context.Depositos.Add(deposito);
            _context.SaveChanges();

            _repositoryDeposito.BorrarDeposito(deposito);

            var depositosInDb = _repositoryDeposito.ObtenerDepositos();
            Assert.IsFalse(depositosInDb.Contains(deposito));
            Assert.AreEqual(0, depositosInDb.Count());
        }

        [TestMethod]
        public void test_ExisteDeposito()
        {
            var deposito = new Deposito
            {
                ID = 1,
                Area = EnumArea.A,
                Tamano = EnumTamano.Pequeno,
                Climatizado = true
            };

            _context.Depositos.Add(deposito);
            _context.SaveChanges();

            var existe = _repositoryDeposito.ExisteDeposito(deposito);

            Assert.IsTrue(existe);
        }
    }
}
